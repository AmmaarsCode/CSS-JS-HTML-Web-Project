companies = ['Java ','Tesla ','URMOM! ','replit ','github ','dell ','apple ','facebook ','google ','netflix ','youtube ','linkedin ','quicktrip ','bereal ','target ','walmart '
 ]

fruits = ['Orange ','Strawberry ','Pineapple ','apple ','cocunut ','peach ','banana '
]

numbers = ['12','22','45','89','23','43','90','12','32','43','65','41','88','71','40','46','09','31'
]

fruit=0
for (x in fruits){
  fruit+=1
}

number=0
for (t in numbers){
  number+=1
}

comps=0
for (i in companies){
  comps+=1
}

function compName(){
  math=Math.floor(Math.random()*comps)
  first=companies[math]
  math2=Math.floor(Math.random()*number)
  last=numbers[math2]
  console.log(first+last)
  s=document.getElementById('hh').innerHTML=first+last
}

function fruitName(){
  math=Math.floor(Math.random()*fruit)
  first=fruits[math]
  math2=Math.floor(Math.random()*number)
  last=numbers[math2]
  console.log(first+last)
  s=document.getElementById('hh').innerHTML=first+last
}